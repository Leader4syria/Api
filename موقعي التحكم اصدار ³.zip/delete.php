<?php
require_once 'auth.php';

if (!isLoggedIn()) {
    http_response_code(403);
    exit;
}

$tool_name = $_POST['tool_name'] ?? '';
if (empty($tool_name)) {
    echo json_encode(['success' => false, 'message' => 'اسم الأداة مطلوب']);
    exit;
}

$toolFile = "tools/$tool_name.json";

// فقط المالك أو الأدمن يمكنه الحذف
if (file_exists($toolFile)) {
    $data = json_decode(file_get_contents($toolFile), true);
    if ($data['owner'] !== currentUser() && !isAdmin()) {
        http_response_code(403);
        exit;
    }
    
    if (unlink($toolFile)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'فشل في حذف الأداة']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'الأداة غير موجودة']);
}
?>