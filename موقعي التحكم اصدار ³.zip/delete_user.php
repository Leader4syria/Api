<?php
require_once 'auth.php';

if (!isAdmin()) {
    header('HTTP/1.1 403 Forbidden');
    exit(json_encode(['success' => false, 'message' => 'غير مصرح']));
}

$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'] ?? '';

if (empty($username)) {
    exit(json_encode(['success' => false, 'message' => 'اسم المستخدم مطلوب']));
}

// منع حذف المستخدم الحالي والمستخدم admin والضيوف
if ($username === currentUser() || $username === 'admin' || isGuest($username)) {
    exit(json_encode(['success' => false, 'message' => 'لا يمكن حذف هذا المستخدم']));
}

$users = loadUsers();
if (!isset($users[$username])) {
    exit(json_encode(['success' => false, 'message' => 'المستخدم غير موجود']));
}

// حذف أدوات المستخدم
$toolsDeleted = 0;
foreach (scandir('tools') as $file) {
    if (pathinfo($file, PATHINFO_EXTENSION) === 'json') {
        $toolFile = "tools/$file";
        $data = json_decode(file_get_contents($toolFile), true);
        if ($data['owner'] === $username) {
            if (unlink($toolFile)) {
                $toolsDeleted++;
            }
        }
    }
}

// حذف المستخدم
unset($users[$username]);
file_put_contents(USERS_FILE, json_encode($users, JSON_PRETTY_PRINT));

echo json_encode([
    'success' => true,
    'message' => "تم حذف المستخدم بنجاح مع $toolsDeleted أداة",
    'users' => $users // إرجاع قائمة المستخدمين المحدثة
]);
?>