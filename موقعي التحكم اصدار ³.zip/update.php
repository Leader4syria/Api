<?php
require_once 'auth.php';

if (!isLoggedIn()) {
    http_response_code(403);
    exit(json_encode(['success' => false, 'message' => 'غير مصرح']));
}

$tool_name = $_POST['tool_name'] ?? '';
$status = $_POST['status'] ?? 'ON';
$duration = intval($_POST['duration'] ?? 0);

if (empty($tool_name)) {
    exit(json_encode(['success' => false, 'message' => 'اسم الأداة مطلوب']));
}

// إنشاء بيانات الأداة
$toolData = [
    'owner' => currentUser(),
    'status' => $status,
    'start_time' => time(),
    'duration' => $duration * 60, // تحويل الدقائق إلى ثواني
    'created_at' => date('Y-m-d H:i:s')
];

// حفظ الأداة
$toolFile = "tools/$tool_name.json";
if (file_put_contents($toolFile, json_encode($toolData, JSON_PRETTY_PRINT))) {
    echo json_encode(['success' => true, 'message' => 'تمت إضافة الأداة بنجاح']);
} else {
    echo json_encode(['success' => false, 'message' => 'فشل في حفظ الأداة']);
}
?>