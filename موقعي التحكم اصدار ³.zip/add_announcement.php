<?php
require_once 'auth.php';

if (!isAdmin()) {
    http_response_code(403);
    exit(json_encode(['success' => false, 'message' => 'غير مصرح']));
}

$data = json_decode(file_get_contents('php://input'), true);
$text = $data['text'] ?? '';

if (empty($text)) {
    exit(json_encode(['success' => false, 'message' => 'نص الإعلان مطلوب']));
}

addAnnouncement($text, currentUser());
echo json_encode(['success' => true, 'message' => 'تمت إضافة الإعلان بنجاح']);
?>