<?php
require_once 'auth.php';

if (!isAdmin()) {
    header('HTTP/1.1 403 Forbidden');
    exit(json_encode(['success' => false, 'message' => 'غير مصرح']));
}

$data = json_decode(file_get_contents('php://input'), true);
$mode = $data['mode'] ?? '';

if (!in_array($mode, ['paid', 'free'])) {
    exit(json_encode(['success' => false, 'message' => 'وضع غير صالح']));
}

// إذا تم التحويل للوضع المدفوع، تسجيل خروج جميع الضيوف
if ($mode === 'paid') {
    $users = loadUsers();
    foreach ($users as $username => $data) {
        if (strpos($username, 'guest') === 0) {
            // حذف أدوات الضيوف
            foreach (scandir('tools') as $file) {
                if (pathinfo($file, PATHINFO_EXTENSION) === 'json') {
                    $toolFile = "tools/$file";
                    $toolData = json_decode(file_get_contents($toolFile), true);
                    if ($toolData['owner'] === $username) {
                        unlink($toolFile);
                    }
                }
            }
            // حذف المستخدم الضيف
            unset($users[$username]);
        }
    }
    saveUsers($users);
}

setPaymentMode($mode);
echo json_encode(['success' => true, 'message' => 'تم تغيير الوضع بنجاح']);
?>